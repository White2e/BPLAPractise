from practise4 import Drone

drone1 = Drone("T-1000", 5, 2, "1312314У")
drone1.get_info()
drone1.get_coords()
drone1.get_dist()

