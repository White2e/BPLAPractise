# design-patterns
Code examples from my book "Principles and software design patterns": https://urait.ru/bcode/497029
