### Use PyAssimilator in your projects

The easiest way to help us and yourself is to use the framework!
Your code will be better with our patterns, and that will allow us to improve
PyAssimilator!

### Star the library

[Star](https://github.com/knucklesuganda/py_assimilator) PyAssimilator on GitHub.
That will help us a lot! Also, you will be placed in a list of 
[⭐Stargazers⭐](/#stargazers)!

### Ask questions in PyAssimilator communities

You can ask questions on our GitHub or Discord
if you have any issues with PyAssimilator. There is also an option to
contact <a href="mailto:python.on.papyrus@gmail.com">Andrey(primary creator of PyAssimilator)</a>.

### Create Pull Requests

If you want to add something to the library, then you can create pull requests on our GitHub.
You will be added to the list of [Contributors](/#contributors)!

