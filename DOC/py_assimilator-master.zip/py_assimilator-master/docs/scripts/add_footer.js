document.getElementsByClassName("md-footer-meta__inner md-grid")[0].innerHTML += `
<div class="md-copyright"><a href="/management/privacy" target="_blank" rel="noopener">Privacy policy</a></div>`;
