

class PatternNotFoundError(KeyError):
    pass


class ProviderNotFoundError(KeyError):
    pass
