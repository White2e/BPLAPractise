
class ParsingError(Exception):
    pass
