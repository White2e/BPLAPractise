from abc import ABC


class Service(ABC):
    pass


__all__ = [
    'Service',
]
